import { useState, useEffect } from "react";
import type { Categoria } from "./types/categoria";
import Navbar from "./components/Navbar";
import CategoriaList from "./components/CategoriaList";
import CategoriaModal from "./components/CategoriaModal";

const API_URL = "http://localhost:8000/categorias";

function App() {
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [modalAbierto, setModalAbierto] = useState(false);
  const [categoriaEditar, setCategoriaEditar] = useState<Categoria | null>(null);

  // GET - Cargar categorías al montar
  useEffect(() => {
    handleFetchCategorias();
  }, []);

  const handleFetchCategorias = async () => {
    try {
      const response = await fetch(API_URL);
      const data: Categoria[] = await response.json();
      setCategorias(data);
    } catch (error) {
      console.error("Error al obtener categorías:", error);
    }
  };

  // POST - Crear categoría
  const handleCreate = async (data: { nombre: string; descripcion: string }) => {
    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error("Error al crear la categoría");
      }

      handleFetchCategorias();
      setModalAbierto(false);
    } catch (error) {
      console.error("Error:", error);
      alert("Error al crear la categoría");
    }
  };

  // PATCH - Actualizar categoría
  const handleUpdate = async (data: { nombre: string; descripcion: string }) => {
    if (!categoriaEditar) return;

    try {
      const response = await fetch(`${API_URL}/${categoriaEditar.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error("Error al actualizar la categoría");
      }

      handleFetchCategorias();
      setModalAbierto(false);
      setCategoriaEditar(null);
    } catch (error) {
      console.error("Error:", error);
      alert("Error al actualizar la categoría");
    }
  };

  // DELETE - Eliminar categoría
  const handleDelete = async (id: number) => {
    

    try {
      const response = await fetch(`${API_URL}/${id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        throw new Error("Error al eliminar la categoría");
      }

      handleFetchCategorias();
    } catch (error) {
      console.error("Error:", error);
      alert("Error al eliminar la categoría");
    }
  };

  // Abrir modal para crear
  const abrirModalCrear = () => {
    setCategoriaEditar(null);
    setModalAbierto(true);
  };

  // Abrir modal para editar
  const abrirModalEditar = (categoria: Categoria) => {
    setCategoriaEditar(categoria);
    setModalAbierto(true);
  };

  // Manejar submit del modal (crear o editar según corresponda)
  const handleModalSubmit = (data: { nombre: string; descripcion: string }) => {
    if (categoriaEditar) {
      handleUpdate(data);
    } else {
      handleCreate(data);
    }
  };

  // Cerrar modal
  const cerrarModal = () => {
    setModalAbierto(false);
    setCategoriaEditar(null);
  };

  return (
    <>
      <Navbar onAgregar={abrirModalCrear} />

      <CategoriaList
        categorias={categorias}
        onEditar={abrirModalEditar}
        onEliminar={handleDelete}
      />

      <CategoriaModal
        isOpen={modalAbierto}
        categoria={categoriaEditar}
        onClose={cerrarModal}
        onSubmit={handleModalSubmit}
      />
    </>
  );
}

export default App;
