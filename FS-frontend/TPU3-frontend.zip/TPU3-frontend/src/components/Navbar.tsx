type NavbarProps = {
  onAgregar: () => void;
};

const Navbar = ({ onAgregar }: NavbarProps) => {
  return (
    <div className="bg-gradient-to-r from-indigo-600 to-purple-600 shadow-lg">
      <div className="max-w-4xl mx-auto px-4 py-6 flex items-center justify-between">
        <h1 className="text-3xl font-bold text-white tracking-tight">
          Categorías
        </h1>
        <button
          onClick={onAgregar}
          className="flex items-center gap-2 px-5 py-2.5 bg-white text-indigo-600 font-semibold rounded-lg hover:bg-indigo-50 transition-all shadow-md hover:shadow-lg"
        >
          <span className="text-xl leading-none">+</span>
          <span>Agregar Categoría</span>
        </button>
      </div>
    </div>
  );
};

export default Navbar;
