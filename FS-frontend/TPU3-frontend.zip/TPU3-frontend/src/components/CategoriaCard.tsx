import type { Categoria } from "../types/categoria";

type CategoriaCardProps = {
  categoria: Categoria;
  onEditar: (categoria: Categoria) => void;
  onEliminar: (id: number) => void;
};

const CategoriaCard = ({ categoria, onEditar, onEliminar }: CategoriaCardProps) => {
  return (
    <tr className="bg-white hover:bg-indigo-50 transition-colors duration-200">
      <td className="px-6 py-4 text-sm text-indigo-600 font-semibold">
        {categoria.id}
      </td>
      <td className="px-6 py-4 text-sm font-medium text-gray-900">
        {categoria.nombre}
      </td>
      <td className="px-6 py-4 text-sm text-gray-600">
        {categoria.descripcion}
      </td>
      <td className="px-6 py-4">
        <div className="flex gap-2">
          <button
            onClick={() => onEditar(categoria)}
            className="px-4 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-all shadow-md hover:shadow-lg"
          >
            Editar
          </button>
          <button
            onClick={() => onEliminar(categoria.id)}
            className="px-4 py-2 bg-red-600 text-white font-medium rounded-lg hover:bg-red-700 transition-all shadow-md hover:shadow-lg"
          >
            Eliminar
          </button>
        </div>
      </td>
    </tr>
  );
};

export default CategoriaCard;
