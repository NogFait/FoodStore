import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import ProductoList from "../components/ProductoList/ProductoList";
import type { Producto } from "../types/producto";
import ProductoModal from "../components/ProductoModal/ProductoModal";
import ProductoDetailModal from "../components/ProductoDetailModal/ProductoDetailModal";
import ConfirmModal from "../components/ConfirmModal/ConfirmModal";


// Estado del modal - Union Type
type ModalState =
  | { type: "none" }
  | { type: "create" }
  | { type: "edit"; producto: Producto }
  | { type: "detail"; producto: Producto }
  | { type: "confirm-delete"; productoId: number };

const ProductosPage = () => {
  const [modal, setModal] = useState<ModalState>({ type: "none" });
  const queryClient = useQueryClient();
  const API_URL = "http://localhost:8000/productos/";


  const getProductos = async () => {
    const res = await fetch(API_URL);
    if (!res.ok) {
      throw new Error("Ocurrio un error");
    }
    return res.json();
  };

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["productos"],
    queryFn: getProductos,
    staleTime: 10000*60,
  });

  // Agregar query de categorías
const { data: categorias } = useQuery({
  queryKey: ["categorias"],
  queryFn: async () => {
    const res = await fetch("http://localhost:8000/categorias/");
    return res.json();
  },
});


  //Crear Mutacion
  const createMutation = useMutation({
    mutationFn: async(data: Omit<Producto,"id">)=>{
      const res = await fetch(API_URL,{
          method: "POST",
          headers: {"Content-Type": "application/json"},
          body: JSON.stringify(data),
      });
      if(!res.ok) throw new Error("Error al crear")
        return res.json()
    },
    onSuccess: ()=>{
      queryClient.invalidateQueries({queryKey: ["productos"]})
      setModal({type: "none"})
    }
  })

const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${API_URL}${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Error al eliminar");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["productos"] });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Omit<Producto, "id"> }) => {
      const res = await fetch(`${API_URL}${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Error al actualizar");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["productos"] });
      setModal({ type: "none" });
    },
  });

  // Handlers
  const handleCloseModal = ()=>{
    setModal({type: "none"})
  }
  const handleCreate = (data: Omit<Producto, "id">) => {
    createMutation.mutate(data);
  };

  const handleUpdate = (id: number, data: Omit<Producto, "id">) => {
    updateMutation.mutate({ id, data });
  };

  const handleEdit = (producto: Producto) => {
    setModal({ type: "edit", producto });
  };

  const handleView = (producto: Producto) => {
    setModal({ type: "detail", producto });
  };

  const handleDelete = (id: number) => {
    setModal({ type: "confirm-delete", productoId: id });
  };

  const handleConfirmDelete = () => {
    if (modal.type === "confirm-delete") {
      deleteMutation.mutate(modal.productoId);
      setModal({ type: "none" });
    }
  };


  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Productos</h1>
            <p className="mt-1 text-sm text-gray-500">
              {data ? `${data.length} productos encontrados` : "Cargando..."}
            </p>
          </div>
          <button
            onClick={() => setModal({type: "create"})}
            className="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Nuevo Producto
          </button>
        </div>

        {isLoading && (
          <div className="flex justify-center items-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-600 border-t-transparent"></div>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-center">
            <svg className="mx-auto h-12 w-12 text-red-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <p className="text-red-600 font-medium">Ocurrio un error al cargar los productos</p>
            <button onClick={() => refetch()} className="mt-4 text-sm text-indigo-600 hover:text-indigo-800 font-medium">
              Reintentar
            </button>
          </div>
        )}

        {data && data.length === 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <svg className="mx-auto h-16 w-16 text-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
            </svg>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No hay productos</h3>
            <p className="text-gray-500 mb-6">Comenza agregando tu primer producto</p>
            <button
              onClick={() => setModal({type: "create"})}
              className="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition-all duration-200"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Agregar Producto
            </button>
          </div>
        )}

        {data && data.length > 0 && (
          <ProductoList
            productos={data}
            categorias={categorias || []}
            onEdit={handleEdit}
            onDelete={handleDelete}
            onView={handleView}
          />
        )}
      </div>

      {/* Modal: CREATE */}
      {modal.type === "create" && (
        <ProductoModal
        isOpen={modal.type === "create"} 
          producto={null}
          onClose={handleCloseModal}
          onSubmit={handleCreate}
          categorias={categorias || []} 
        />
      )}

      {/* Modal: EDIT */}
      {modal.type === "edit" && (
        <ProductoModal
          isOpen={modal.type === "edit"} 
          producto={modal.producto}
          onClose={handleCloseModal}
          onSubmit={(data) => handleUpdate(modal.producto.id, data)} 
          categorias={categorias || []} 
        />
      )}

      {/* Modal: DETAIL */}
      {modal.type === "detail" && (
        <ProductoDetailModal
          producto={modal.producto}
          categorias={categorias || []}
          onClose={handleCloseModal}
        />
      )}

      {/* Modal: CONFIRM DELETE */}
      {modal.type === "confirm-delete" && (
        <ConfirmModal
          isOpen={true}
          title="Eliminar producto"
          message="¿Estás seguro de eliminar este producto? Esta acción no se puede deshacer."
          onConfirm={handleConfirmDelete}
          onCancel={handleCloseModal}
        />
      )}
    </div>
  );
};

export default ProductosPage;
