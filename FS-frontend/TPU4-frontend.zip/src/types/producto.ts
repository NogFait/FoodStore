
export interface Producto {
  id: number;
  nombre: string;
  descripcion: string;
  precio_base: number;
  imagen_url?: string;
  categorias_ids: number[];
}
