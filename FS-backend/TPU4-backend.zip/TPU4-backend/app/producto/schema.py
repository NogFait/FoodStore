from typing import Optional, List
from sqlmodel import SQLModel, Field
from datetime import datetime

class ProductoBase(SQLModel):
    nombre:str
    descripcion:str
    precio_base:float
    imagen_url: Optional[str] = None
    disponible: bool

    categorias_ids: List[int] = []

class ProductoCreate(ProductoBase):
    pass

class ProductoResponse(ProductoBase):
    id:int

class ProductoUpdate(SQLModel):
    #Todos opcionales para permitir updates parciales
    nombre: Optional[str] = None
    descripcion: Optional[str] = None
    precio_base:Optional[float] = None
    imagen_url: Optional[str] = Field(default_factory=list)
    disponible: Optional[bool] = None
    categorias_ids: Optional[List[int]] = None