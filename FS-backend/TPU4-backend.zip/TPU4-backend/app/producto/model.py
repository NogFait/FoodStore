from typing import Optional, List
from sqlmodel import SQLModel, Field, Relationship

from app.categoria.model import Categoria
from ..producto_categoria.model import ProductoCategoria
from datetime import datetime

class Producto(SQLModel, table=True):
    #ID generado por la base de datos
    id: Optional[int] = Field(default=None, primary_key=True)

    nombre: str
    descripcion:str
    precio_base:float
    imagen_url: Optional[str] = None
    disponible: bool

    categorias: List["Categoria"] = Relationship(
        back_populates = "productos",
        link_model = ProductoCategoria
    )

    #CAMPOS DE AUDITORÍA 
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None

    @property
    def categorias_ids(self) -> List[int]:
        return [cat.id for cat in self.categorias] if self.categorias else []