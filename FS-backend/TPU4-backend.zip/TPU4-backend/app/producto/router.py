from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session

from ..core.database import get_session

from .schema import ProductoCreate, ProductoResponse, ProductoUpdate
from .service import create_producto, delete_producto, list_productos, update_producto, get_producto_by_id

router_producto = APIRouter(prefix="/productos",tags=["productos"])

#Crear Categoria
@router_producto.post("/",response_model= ProductoResponse)
def create(producto: ProductoCreate, session: Session = Depends(get_session)):
    #EL endpoint solo delega
    return create_producto(session, producto)

#Listar todos los productos
@router_producto.get("/", response_model=list[ProductoResponse])
def list_all(session: Session = Depends(get_session)):
    return list_productos(session)

#Obtener producto por su Id
@router_producto.get("/{producto_id}")
def get_by_id(producto_id: int, session: Session = Depends(get_session)):
    try:
        get_producto_by_id(session, producto_id)
        return {"message": "Producto encontrado correctamente"}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

#Actualizar por completo o por partes un Producto por su ID
@router_producto.patch("/{producto_id}", response_model=ProductoResponse)
def update( producto_id:int, producto:ProductoUpdate, session: Session = Depends(get_session)):
    try:
        return update_producto(session, producto_id, producto)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

#Eliminar un Producto por su ID
@router_producto.delete("/{producto_id}")
def delete(producto_id: int, session: Session = Depends(get_session)):
    try:
        delete_producto(session, producto_id)
        return {"message": "Producto eliminado correctamente"}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))