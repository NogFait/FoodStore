from sqlmodel import Session, select
from .model import Producto
from .schema import ProductoCreate, ProductoUpdate
from ..categoria.model import Categoria
from datetime import datetime

def create_producto(session: Session, data: ProductoCreate) -> Producto:
    #El servicio recibe la sesión y los datos ya vlaidados
    producto = Producto.model_validate(data)
    
    if hasattr(data, "categorias_ids"):
        categorias = session.exec(
            select(Categoria).where(Categoria.id.in_(data.categorias_ids))
        ).all()
        producto.categorias = categorias
        
    #La transacción se controla acá
    session.add(producto)
    session.commit()
    session.refresh(producto)

    return producto


def delete_producto(session: Session, producto_id: int) -> bool:
    """Elimina un producto por su ID. Retorna True si se eliminó."""
    producto = session.get(Producto, producto_id)

    if not producto:
        raise ValueError("Producto no encontrado")

    session.delete(producto)
    session.commit()

    return True

def get_producto_by_id(session:Session, producto_id:int) -> Producto:
    #session.get genera un SELECT ... LIMIT 1
    producto = session.get(Producto,producto_id)

    if not producto:
        raise ValueError("Item no encontrado")
    

    return producto


def list_productos(session: Session) -> list[Producto]:
    #Construimos una consulta explícita usando SQLModel / SQLAlchemy
    
    statement = select(Producto)

    #session.exec(statement) envia la consulta a la base de datos.
    result = session.exec(statement)

    productos = result.all()

    return productos

def update_producto(session: Session, producto_id: int, data: ProductoUpdate) -> Producto:
    
    producto = session.get(Producto,producto_id)

    if not producto:
        raise ValueError("Producto no encontrado")
    
    #Solo se actualizan los campos enviados
    update_data = data.model_dump(exclude_unset=True)

    #Recorremos los datos que llegaron para la actualización.
    #Update_data es un diccionario con pares {nombre_del_campo: nuevo_valor}

    if "categorias_ids" in update_data:
        categorias_ids = update_data.pop("categorias_ids")
        if categorias_ids is not None:
            categorias = session.exec(
                select(Categoria).where(Categoria.id.in_(categorias_ids))
            ).all()
            producto.categorias = categorias

    for field, value in update_data.items():
        # setattr es una función built-in de Python que permite
        # asignar dinámicamente un atributo a un objeto.
        setattr(producto, field, value)
    producto.updated_at = datetime.now()
    
    session.add(producto)
    session.commit()
    session.refresh(producto)

    return producto