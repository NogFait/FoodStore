from typing import Optional, List
from sqlmodel import SQLModel,Field, Relationship
from ..producto_categoria.model import ProductoCategoria
from app.producto.model import Producto
from datetime import datetime

class Categoria(SQLModel, table=True):
    #ID generado por la base de datos
    id: Optional[int] = Field(default=None,primary_key=True)

    nombre: str
    descripcion: str

    productos: List["Producto"] = Relationship(
        back_populates = "categorias",
        link_model= ProductoCategoria
    )
    
    #CAMPOS DE AUDITORÍA
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None