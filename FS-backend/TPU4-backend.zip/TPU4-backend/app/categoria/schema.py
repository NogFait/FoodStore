from typing import Optional
from sqlmodel import SQLModel

class CategoriaBase(SQLModel):
    nombre: str
    descripcion: str

class CategoriaCreate(CategoriaBase):
    pass

class CategoriaResponse(CategoriaBase):
    id: int

class CategoriaUpdate(SQLModel):
    #Todos opcionales para permitir updates parciales
    nombre: Optional[str] = None
    descripcion: Optional[str] = None