from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session

from ..core.database import get_session
from .schema import CategoriaCreate, CategoriaResponse, CategoriaUpdate
from .service import create_categoria, delete_categoria, list_categorias, update_categoria

router_categoria = APIRouter(prefix="/categorias", tags=["categorias"])

#Crear Categoria
@router_categoria.post("/", response_model=CategoriaResponse)
def create(categoria: CategoriaCreate, session: Session = Depends(get_session)):
    #El endpoint solo delega
    return create_categoria(session, categoria)

#Listar todas las categorias
@router_categoria.get("/",response_model=list[CategoriaResponse])
def list_all(session: Session = Depends(get_session)):
    return list_categorias(session)


#Actualizar por completo o por partes una Categoria por su ID
@router_categoria.patch("/{categoria_id}",response_model=CategoriaResponse)
def update(categoria_id: int, categoria: CategoriaUpdate, session: Session = Depends(get_session)):
    try:
        return update_categoria(session, categoria_id, categoria)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

#Eliminar una Categoria por su ID
@router_categoria.delete("/{categoria_id}")
def delete(categoria_id: int, session: Session = Depends(get_session)):
    try:
        delete_categoria(session, categoria_id)
        return {"message": "Categoria eliminada correctamente"}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


