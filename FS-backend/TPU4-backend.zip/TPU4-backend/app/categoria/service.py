from sqlmodel import Session, select
from .model import Categoria
from .schema import CategoriaCreate, CategoriaUpdate
from datetime import datetime

def create_categoria(session: Session, data: CategoriaCreate) -> Categoria:
    #El servicio recibe la sesión y los datos ya validados
    categoria = Categoria.model_validate(data)

    #La transacción se controla acá
    session.add(categoria)
    session.commit()
    session.refresh(categoria)

    return categoria


def list_categorias(session: Session) -> list[Categoria]:
    #Construimos una consulta explícita usando SQLModel / SQLAlchemy
    # select(Categoria) indica: Quiero seleccionar todas las filas de la tabla asociada al modelo Categoria
    statement = select(Categoria)

    #session.exec(statement) envía la consulta a la base de datos.
    result = session.exec(statement)

    categorias = result.all()

    return categorias

def update_categoria(session: Session, categoria_id: int, data: CategoriaUpdate) -> Categoria:

    categoria = session.get(Categoria,categoria_id)

    if not categoria:
        raise ValueError("Categoria no encontrada")
    
    #Solo se actualizan los campos enviados
    update_data = data.model_dump(exclude_unset=True)

    #Recorremos los datos que llegaron para la actualización.
    # update_data es un diccionario con pares {nombre_del_campo: nuevo_valor}
    for field, value in update_data.items():
        #Recorremos los datos que llegaron para la actualización.
    #Update_data es un diccionario con pares {nombre_del_campo: nuevo_valor}

        if "categorias_ids" in update_data:
            categorias_ids = update_data.pop("categorias_ids")
            if categorias_ids is not None:
                categorias = session.exec(
                    select(Categoria).where(Categoria.id.in_(categorias_ids))
                ).all()
                producto.categorias = categorias
        setattr(categoria, field, value)
    session.add(categoria)
    session.commit()
    session.refresh(categoria)

    return categoria


def delete_categoria(session: Session, categoria_id: int) -> bool:
    """Elimina una categoría por su ID. Retorna True si se eliminó."""
    categoria = session.get(Categoria, categoria_id)

    if not categoria:
        raise ValueError("Categoria no encontrada")

    session.delete(categoria)
    session.commit()

    return True

