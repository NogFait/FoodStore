from sqlmodel import SQLModel, Field
from typing import Optional

class ProductoCategoriaBase(SQLModel, table=True):
    producto_id: int 
    categoria_id: int 
    


class ProductoCategoriaCreate(ProductoCategoriaBase):
    pass

class ProductoCategoriaUpdate(ProductoCategoriaBase):
    id:int

class ProductoCategoriaUpdate(SQLModel):
    producto_id: Optional[int] = None
    categoria_id: Optional[int] = None