from sqlmodel import SQLModel, Field
from typing import Optional

class ProductoCategoria(SQLModel, table=True):
    
    producto_id: int = Field(foreign_key="producto.id", primary_key=True)
    categoria_id: int = Field(foreign_key="categoria.id", primary_key=True)